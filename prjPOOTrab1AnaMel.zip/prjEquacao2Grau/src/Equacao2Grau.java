public class Equacao2Grau {
    private double coef_A;
    private double coef_B;
    private double coef_C;
    
    public Equacao2Grau(double a, double b, double c) {
        coef_A = a;
        coef_B = b;
        coef_C = c;
    }
    
    public double calcDelta() {
        return (coef_B * coef_B) - (4 * coef_A * coef_C);
    }
    
    public double calcRaiz(int raiz) {
        if (coef_A == 0) {
            throw new ArithmeticException("Coeficiente A não pode ser zero.");
        }

        double delta = calcDelta();
        
        if (delta < 0) {
            throw new ArithmeticException("Delta é negativo. Não há raízes reais.");
        }
        
        double raiz1 = (-coef_B + Math.sqrt(delta)) / (2 * coef_A);
        double raiz2 = (-coef_B - Math.sqrt(delta)) / (2 * coef_A);

        if (raiz == 1) {
            return raiz1;
        } else if (raiz == 2) {
            return raiz2;
        } else {
            throw new IllegalArgumentException("O parâmetro 'raiz' deve ser 1 ou 2.");
        }
    }
    
    public String exibeEquacao() {
        StringBuilder sb = new StringBuilder();
        
        if (coef_A != 0) {
            sb.append(coef_A);
            sb.append("x^2");
        }
        
        if (coef_B != 0) {
            if (sb.length() > 0) {
                sb.append(coef_B > 0 ? " + " : " - ");
            } else {
                sb.append(coef_B < 0 ? "-" : "");
            }
            sb.append(Math.abs(coef_B));
            sb.append("x");
        }
        
        if (coef_C != 0) {
            if (sb.length() > 0) {
                sb.append(coef_C > 0 ? " + " : " - ");
            } else {
                sb.append(coef_C < 0 ? "-" : "");
            }
            sb.append(Math.abs(coef_C));
        }
        
        if (sb.length() == 0) {
            sb.append("0");
        }
        
        return sb.toString();
    }
}
