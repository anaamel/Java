import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Ana Mel
 */
public class Aplic {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("#,##0.00");
        
        double a, b, c;
        int raiz1, raiz2;
        
        System.out.print("Digite o coeficiente A: ");
        a = entrada.nextDouble();
        System.out.print("Digite o coeficiente B: ");
        b = entrada.nextDouble();
        System.out.print("Digite o coeficiente C: ");
        c = entrada.nextDouble();
        
        Equacao2Grau objCoef = new Equacao2Grau(a, b, c);
        
        System.out.print("Equação: " + objCoef.exibeEquacao());
        
        try {
            // Verificação do valor de delta e cálculo das raízes
            double delta = objCoef.calcDelta();
            if (delta > 0) {
                System.out.println("Raiz 1: " + df.format(objCoef.calcRaiz(1)));
                System.out.println("Raiz 2: " + df.format(objCoef.calcRaiz(2)));
            } else if (delta == 0) {
                System.out.println("Raiz única: " + df.format(objCoef.calcRaiz(1)));
            } else {
                System.out.println("Não há raízes reais.");
            }
        } catch (Exception e) {
            // Captura e exibe qualquer erro ocorrido durante os cálculos
            System.out.println("Erro: " + e.getMessage());
        }
    }
    
}
